import { nav } from '/component.js';
//네비게이션 바 생성
nav();
